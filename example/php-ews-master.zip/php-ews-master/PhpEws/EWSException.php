<?php
/**
 * Exception class for Exchange Web Services
 *
 * @package php-ews
 * @subpackage Exception
 */

namespace PhpEws;

use Exception;
/**
 * Exception class for Exchange Web Services
 */
class EWSException extends Exception
{
}
